# calcy-math
## _A Simple Math Library_

[![Build Status](https://travis-ci.org/joemccann/dillinger.svg?branch=master)](https://travis-ci.org/joemccann/dillinger)

## Installation

Install the dependencies and devDependencies and start the server.

```sh
cd my_app
pip install calcy-math
```

Importing calcy-math

```
from calcy-math import *
```
Running Server
```
python app.py
```
